package com.variaflow.mobile.ui.theme

import androidx.compose.ui.graphics.Color

val Cyan80 = Color(0xFF80DEEA)
val CyanGrey80 = Color(0xFFB2DFDB)
val LightCyan = Color(0xFFE0F7FA)

val Cyan40 = Color(0xFF00ACC1)
val CyanGrey40 = Color(0xFF00897B)
val DarkCyan = Color(0xFF006064)

val DarkBackground = Color(0xFF0C1013)
val DarkSurface = Color(0xFF161C20)
val DarkSurfaceVariant = Color(0xFF20272B)
val ElectricCyan = Color(0xFF00E5FF)
val WarningAmber = Color(0xFFFFB300)
val SuccessGreen = Color(0xFF00E676)
val ErrorRed = Color(0xFFFF5252)
